<?php
define('DB_HOST', 'localhost');                 # sql311.infinityfree.com
define('DB_NAME', 'project_visit_report');      # if0_42198845_project_report
define('DB_USER', 'root');                      # if0_42198845
define('DB_PASS', 'root');                      # dlEdgV2Wlc542k2
define('DB_CHARSET', 'utf8mb4');